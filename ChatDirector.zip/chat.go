package main

import (
	"golang.org/x/net/websocket"
	"html/template"
	"log"
	"net/http"
	"os/user"
	"os"
	"time"
	"github.com/lucasb-eyer/go-colorful"
	"math/rand"
	"github.com/kennygrant/sanitize"
	"bytes"
)

const (
	listenAddr = "localhost:8080"
)

var (
	pwd, _        = os.Getwd()
	Temp          = template.Must(template.ParseFiles(pwd + "/chat.html"))
	JSON          = websocket.JSON           // codec for JSON
	Message       = websocket.Message        // codec for string, []byte
	ActiveClients = make(map[ClientConn]int) // map containing clients
)

func init() {
	http.HandleFunc("/", RootHandler)
	http.Handle("/sock", websocket.Handler(SockServer))
}

type ClientConn struct {
	websocket *websocket.Conn
	clientIP  string
	client *user.User
	hex string
}

func SockServer(ws *websocket.Conn) {
	var err error
	var clientMessage string
	// use []byte if websocket binary type is blob or arraybuffer
	// var clientMessage []byte

	// cleanup on server side
	defer func() {
		if err = ws.Close(); err != nil {
			log.Println("Websocket could not be closed", err.Error())
		}
	}()

	client := ws.Request().RemoteAddr
	log.Println("Client connected:", client)
	
	rand.Seed( time.Now().UTC().UnixNano())
	userColor := colorful.HappyColor().Hex()
	
	getUser, err := user.Current()
	if err != nil {
		log.Println("Failed to get current user")
		return
	}
	
	sockCli := ClientConn{ws, client, getUser, userColor}
	ActiveClients[sockCli] = 0
	
	var htmlUserString bytes.Buffer
	htmlUserString.WriteString("1")
	
	for k := range ActiveClients {
		htmlUserString.WriteString("<span style=\"color:" + k.hex + "\">" + k.client.Name + "</span>")
	}
	
	for cs, _ := range ActiveClients {
		if err = Message.Send(cs.websocket, htmlUserString.String()); err != nil {
			log.Println("User list update failed for ", cs.clientIP, err.Error())
		}
	}
	
	log.Println("Number of clients connected ...", len(ActiveClients))

	for {
		if err = Message.Receive(ws, &clientMessage); err != nil {
			// If we cannot Read then the connection is closed
			log.Println("Websocket Disconnected waiting", err.Error())
			// remove the ws client conn from our active clients
			delete(ActiveClients, sockCli)
			log.Println("Number of clients still connected ...", len(ActiveClients))
			return
		}
	
		currentTime := time.Now().Local()
		test := currentTime.Format("Jan 2 at 3:04:05PM")
		
		clientMessage = "0<b>" + test + "</b>" +" | " + "<span style=\"color:" + sockCli.hex + "\">" + sockCli.client.Name + "</span>: " + sanitize.HTML(clientMessage)
		for cs, _ := range ActiveClients {
			if err = Message.Send(cs.websocket, clientMessage); err != nil {
				// we could not send the message to a peer
				log.Println("Could not send message to ", cs.clientIP, err.Error())
			}
		}
	}
}

func RootHandler(w http.ResponseWriter, req *http.Request) {
	w.Header().Set("Content-Type", "text/html")
	err := Temp.Execute(w, listenAddr)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}

func main() {
	err := http.ListenAndServe(listenAddr, nil)
	if err != nil {
		panic("ListenAndServe: " + err.Error())
	}
}
